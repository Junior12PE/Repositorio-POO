package Datos;

import java.util.ArrayList;
import java.util.Scanner;

public class Profesor extends Usuario {
	
	String especialidad;
	
	public Profesor(String nombre, String codigo, String especialidad) {
        super(nombre, codigo);
        this.especialidad = especialidad;
    }
	
	public void mostrarDatos() {
        super.mostrarDatos();
        System.out.println("Especialidad: " + especialidad);
    }
	
	public void registrarNotas(ArrayList<Alumno> alumnos) {
        Scanner scanner = new Scanner(System.in);
        for (Alumno alumno : alumnos) {
            System.out.println("Ingrese las notas para el alumno " + alumno.nombre + " (Código: " + alumno.codigo + "): ");
            for (int i = 0; i < 4; i++) {
                System.out.print("Nota " + (i + 1) + ": ");
                double nota = scanner.nextDouble();
                alumno.agregarNota(nota);
            }
        }
    }

}
