package Datos;

public class Curso {
	
	String nombreCurso;
    String codigoCurso;
    int nroCreditos;
    
    public Curso(String nombreCurso, String codigoCurso, int nroCreditos) {
        this.nombreCurso = nombreCurso;
        this.codigoCurso = codigoCurso;
        this.nroCreditos = nroCreditos;
    }
    
    public void asignarCategoria(double promedio) {
        if (promedio >= 18) {
            System.out.println("Categoría: A");
        } else if (promedio >= 14) {
            System.out.println("Categoría: B");
        } else if (promedio >= 10) {
            System.out.println("Categoría: C");
        } else {
            System.out.println("Categoría: D");
        }
    }
    
    public void verificarAprobacion(double promedio) {
        if (promedio > 13) {
            System.out.println("Curso aprobado");
        } else {
            System.out.println("Curso reprobado");
        }
    }

}
