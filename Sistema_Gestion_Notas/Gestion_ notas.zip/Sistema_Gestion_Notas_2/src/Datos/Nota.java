package Datos;

public class Nota {
	
	double nota;
    double promedio;
    
    public Nota(double promedio) {
        this.promedio = promedio;
    }

}
