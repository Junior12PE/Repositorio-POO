package Datos;

import java.util.Scanner;

public class Administrativo extends Usuario{
	
	String area;
	
	public Administrativo(String nombre, String codigo, String area) {
        super(nombre, codigo);
        this.area = area;
    }
	
	public void mostrarDatos() {
        super.mostrarDatos();
        System.out.println("Área: " + area);
    }
	
	public void modificarDatos(Alumno alumno) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Modificar datos del alumno " + alumno.nombre);
        System.out.print("Nuevo ciclo: ");
        alumno.ciclo = scanner.nextLine();
        System.out.print("Nueva carrera: ");
        alumno.carrera = scanner.nextLine();
        System.out.println("Datos modificados exitosamente.");
    }
}
