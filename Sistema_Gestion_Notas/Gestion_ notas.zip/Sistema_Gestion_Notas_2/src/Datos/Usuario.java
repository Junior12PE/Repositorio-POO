package Datos;

public class Usuario {
	
	String nombre;
    String codigo;
    
    public Usuario(String nombre, String codigo) {
        this.nombre = nombre;
        this.codigo = codigo;
    }
    
    public void mostrarDatos() {
        System.out.println("Nombre: " + nombre);
        System.out.println("Código: " + codigo);
    }
    
    

}
