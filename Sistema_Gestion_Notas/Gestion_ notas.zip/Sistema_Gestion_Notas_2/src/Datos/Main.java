package Datos;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {
	
	static Scanner scanner = new Scanner(System.in);
    static ArrayList<Profesor> profesores = new ArrayList<>();
    static ArrayList<Alumno> alumnos = new ArrayList<>();
    static ArrayList<Administrativo> administrativos = new ArrayList<>();

	public static void main(String[] args) {
		
		int opcion;
        do {
            mostrarMenu();
            opcion = scanner.nextInt();
            scanner.nextLine();
            switch (opcion) {
                case 1:
                    registrarProfesor();
                    break;
                case 2:
                    registrarAlumno();
                    break;
                case 3:
                    registrarAdministrativo();
                    break;
                case 4:
                    System.out.println("Saliendo...");
                    break;
                default:
                    System.out.println("Opción no válida. Intente nuevamente.");
            }
        } while (opcion != 4);

	}
	
	public static void mostrarMenu() {
        System.out.println("\nMenú:");
        System.out.println("1. Ingresar/registrar profesores");
        System.out.println("2. Ingresar/registrar alumnos");
        System.out.println("3. Ingresar/registrar administrativos");
        System.out.println("4. Salir");
        System.out.print("Seleccione una opción: ");
    }
	
	public static void registrarProfesor() {
        System.out.println("\nRegistro de Profesor");
        System.out.print("Ingrese el nombre del profesor: ");
        String nombre = scanner.nextLine();
        System.out.print("Ingrese el código del profesor: ");
        String codigo = scanner.nextLine();
        System.out.print("Ingrese la especialidad del profesor: ");
        String especialidad = scanner.nextLine();
        Profesor profesor = new Profesor(nombre, codigo, especialidad);
        profesores.add(profesor);
        System.out.println("Profesor registrado exitosamente.");
        menuProfesor(profesor);
    }
	
	public static void menuProfesor(Profesor profesor) {
        int opcion;
        do {
            System.out.println("\nMenú del Profesor:");
            System.out.println("1. Registrar notas de los alumnos");
            System.out.println("2. Mostrar datos de los alumnos");
            System.out.println("3. Salir");
            System.out.print("Seleccione una opción: ");
            opcion = scanner.nextInt();
            scanner.nextLine();
            switch (opcion) {
                case 1:
                    profesor.registrarNotas(alumnos);
                    break;
                case 2:
                    mostrarDatosAlumnos();
                    break;
                case 3:
                    System.out.println("Saliendo...");
                    break;
                default:
                    System.out.println("Opción no válida. Intente nuevamente.");
            }
        } while (opcion != 3);
    }
	
	public static void registrarAlumno() {
        System.out.println("\nRegistro de Alumno");
        System.out.print("Ingrese el nombre del alumno: ");
        String nombre = scanner.nextLine();
        System.out.print("Ingrese el código del alumno: ");
        String codigo = scanner.nextLine();
        System.out.print("Ingrese el ciclo del alumno: ");
        String ciclo = scanner.nextLine();
        System.out.print("Ingrese la carrera del alumno: ");
        String carrera = scanner.nextLine();
        Alumno alumno = new Alumno(nombre, codigo, ciclo, carrera);
        alumnos.add(alumno);
        System.out.println("Alumno registrado exitosamente.");
        menuAlumno(alumno);
    }
	
	public static void menuAlumno(Alumno alumno) {
        int opcion;
        do {
            System.out.println("\nMenú del Alumno:");
            System.out.println("1. Ver mis notas y promedio");
            System.out.println("2. Salir");
            System.out.print("Seleccione una opción: ");
            opcion = scanner.nextInt();
            scanner.nextLine();
            switch (opcion) {
                case 1:
                    alumno.mostrarDatos();
                    break;
                case 2:
                    System.out.println("Saliendo...");
                    break;
                default:
                    System.out.println("Opción no válida. Intente nuevamente.");
            }
        } while (opcion != 2);
    }
	
	 public static void registrarAdministrativo() {
	        System.out.println("\nRegistro de Administrativo");
	        System.out.print("Ingrese el nombre del administrativo: ");
	        String nombre = scanner.nextLine();
	        System.out.print("Ingrese el código del administrativo: ");
	        String codigo = scanner.nextLine();
	        System.out.print("Ingrese el área del administrativo: ");
	        String area = scanner.nextLine();
	        Administrativo administrativo = new Administrativo(nombre, codigo, area);
	        administrativos.add(administrativo);
	        System.out.println("Administrativo registrado exitosamente.");
	        menuAdministrativo(administrativo);
	}
	
	 public static void menuAdministrativo(Administrativo administrativo) {
	        int opcion;
	        do {
	            System.out.println("\nMenú del Administrativo:");
	            System.out.println("1. Modificar datos de los alumnos");
	            System.out.println("2. Salir");
	            System.out.print("Seleccione una opción: ");
	            opcion = scanner.nextInt();
	            scanner.nextLine();
	            switch (opcion) {
	                case 1:
	                    modificarDatosAlumno();
	                    break;
	                case 2:
	                    System.out.println("Saliendo...");
	                    break;
	                default:
	                    System.out.println("Opción no válida. Intente nuevamente.");
	            }
	        } while (opcion != 2);
	    }
	
	 public static void modificarDatosAlumno() {
	        System.out.println("\nModificar Datos del Alumno");
	        System.out.print("Ingrese el código del alumno a modificar: ");
	        String codigo = scanner.nextLine();
	        Alumno alumnoEncontrado = null;
	        for (Alumno alumno : alumnos) {
	            if (alumno.codigo.equals(codigo)) {
	                alumnoEncontrado = alumno;
	                break;
	            }
	        }
	        if (alumnoEncontrado != null) {
	            Administrativo admin = administrativos.get(0);
	            admin.modificarDatos(alumnoEncontrado);
	        } else {
	            System.out.println("Alumno no encontrado.");
	        }
	    }
	 
	 public static void mostrarDatosAlumnos() {
	        System.out.println("\nDatos de los Alumnos:");
	        for (Alumno alumno : alumnos) {
	            alumno.mostrarDatos();
	        }
	    }
}
