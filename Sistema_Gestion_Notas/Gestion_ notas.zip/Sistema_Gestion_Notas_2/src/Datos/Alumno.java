package Datos;

import java.util.ArrayList;

public class Alumno extends Usuario {
	
	String ciclo;
    String carrera;
    ArrayList<Double> notas;
    
    public Alumno(String nombre, String codigo, String ciclo, String carrera) {
        super(nombre, codigo);
        this.ciclo = ciclo;
        this.carrera = carrera;
        this.notas = new ArrayList<>();
    }
    
    
    public void agregarNota(double nota) {
        this.notas.add(nota); 
    }
    
    
    public void mostrarDatos() {
        super.mostrarDatos();
        System.out.println("Ciclo: " + ciclo);
        System.out.println("Carrera: " + carrera);
    }
    
    public void mostrarNotasYPromedio() {
        if (notas.isEmpty()) {
            System.out.println("No hay notas registradas.");
        } else {
            double sumaNotas = 0;
            for (double nota : notas) {
                sumaNotas += nota;
            }
            double promedio = sumaNotas / notas.size();
            System.out.println("Notas: " + notas);
            System.out.println("Promedio: " + promedio);
            System.out.println(promedio >= 13 ? "Aprobado" : "Reprobado");
        }
    }
}
